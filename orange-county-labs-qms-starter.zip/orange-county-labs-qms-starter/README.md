# Orange County Labs QMS

A laboratory-specific Electronic Document Control and Quality Management System.

## Initial scope

The platform is designed to support:

- Electronic Document Control
- Record Management
- Personnel Documentation
- Training
- Competency
- Quality Events / Nonconformance
- RCA
- CAPA
- Risk Management
- Equipment
- Reagents
- Test Menu
- Validation / Verification
- Proficiency Testing
- Internal Audits
- Management Review
- Inspection Readiness
- Electronic Signatures
- Immutable Audit Trails
- Notifications
- Reporting
- Future LIMS integration
- Read-only AI quality assistant

## Important regulatory statement

This repository does **not** represent a certification of CAP, CLIA, ISO 15189, HIPAA, or 21 CFR Part 11 compliance. It is an engineering baseline for a system that can support applicable laboratory processes. Formal requirements analysis, validation, implementation controls, policies, procedures, security review, and laboratory approval are required before production use.

## Architecture

Target architecture:

- Next.js / React / TypeScript web application
- TypeScript backend/service layer
- PostgreSQL
- S3-compatible object storage
- durable background-job system
- role/permission authorization
- immutable audit subsystem
- electronic-signature subsystem
- automated test suite
- future API/event integration with LIMS

## Repository layout

```text
apps/
  web/
  api/

packages/
  database/
  auth/
  ui/
  documents/
  records/
  personnel/
  training/
  competency/
  quality/
  capa/
  risk/
  equipment/
  reagents/
  validation/
  pt/
  audits/
  notifications/
  audit/
  signatures/
  reporting/
  ai/

docs/
  requirements/
  architecture/
  validation/
  security/
  regulatory/
  release/

database/
  migrations/
  seeds/

prompts/
  001-architecture.md
  002-foundation.md
  003-database.md
  004-auth.md
  005-audit.md
```

## First implementation milestone

The first milestone is deliberately narrow:

1. repository foundation
2. PostgreSQL connection
3. organization/site/department model
4. users/roles/permissions
5. immutable audit foundation
6. secure file abstraction

Document control and signatures come after the security/audit foundation.

## Local development

The exact commands should be established by Codex during repository initialization and documented here. Do not invent commands until the selected framework/toolchain is committed.

## Source-control policy

Never commit:
- production credentials
- API keys
- private certificates
- patient/employee production data
- production database dumps

Use `.env.example` for configuration documentation.
