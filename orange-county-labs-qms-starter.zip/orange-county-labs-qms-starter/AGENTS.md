# Orange County Labs QMS — Codex Repository Instructions

## Mission
Build a secure, auditable laboratory Quality Management System (QMS/LQMS) for Orange County Labs. The system must support controlled documents, records, personnel, training, competency, quality events, CAPA, risk, equipment, reagents, validation, PT, audits, management review, inspection readiness, electronic signatures, immutable audit trails, reporting, and a future LIMS integration.

## Non-negotiable engineering rules

1. Never weaken authorization to make a test pass.
2. Never allow ordinary CRUD to modify immutable regulated history.
3. Never overwrite a controlled document version; create a new version.
4. Every consequential change to a regulated object must produce an audit event.
5. Audit events must not be editable through normal application APIs.
6. Electronic signatures are workflow events, not image files.
7. A signature must bind the signer, action, record/version, timestamp, meaning, and authentication event.
8. AI is advisory/read-only by default. AI must not approve, sign, close CAPA, alter records, or modify audit trails.
9. Never claim CAP, CLIA, ISO 15189, HIPAA, or 21 CFR Part 11 compliance merely because a feature exists.
10. Do not copy proprietary CAP checklist text or proprietary competitor content. Use configurable requirement records and licensed/current source material.
11. Never store secrets in source control.
12. Use database migrations; do not edit an already-applied migration.
13. Every regulated workflow needs automated tests.
14. Every API must enforce server-side authorization and tenant isolation.
15. Prefer soft deletion/archive workflows for regulated objects.
16. Exporting regulated records must be auditable.
17. Preserve source-of-truth relationships between documents, personnel, tests, equipment, reagents, events, CAPA, audits, and evidence.
18. Do not introduce a breaking architectural change without an ADR.

## Definition of done

A task is not complete until:
- implementation is documented;
- typecheck/lint/tests/build pass;
- authorization tests exist for protected resources;
- audit behavior is tested where applicable;
- migrations work from a clean database;
- no secrets are introduced;
- unresolved risks are documented.

## Preferred development sequence

Plan -> implement -> test -> review diff -> document -> commit.

For large changes, create/update an ADR before coding.

## Regulatory posture

The application is a software tool that supports laboratory quality-system processes. Laboratory management remains responsible for determining applicable requirements, implementing procedures, validating the system, maintaining records, and establishing compliance.
