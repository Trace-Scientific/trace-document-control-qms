# Prompt 005 — Immutable Audit Trail

Implement the audit domain before regulated business modules.

Every consequential create/update/delete/approve/sign/download/export action must produce an audit event.

Audit events must contain:
- actor
- organization
- timestamp
- action
- entity
- entity ID
- version
- previous/new state hashes
- correlation ID
- metadata

Prevent normal application APIs from modifying audit events.

Add automated integrity and authorization tests.
