# Prompt 003 — Database Foundation

Implement the database migrations under database/migrations.

Start with:
- organizations
- sites
- departments
- users
- roles
- permissions
- user_roles
- role_permissions
- audit_events

Use UUIDs, foreign keys, indexes, timestamps, and organization isolation.

Create development seed data only. Do not use production PHI/PII.

Write migration and database tests.
