# Prompt 001 — Architecture

Read the repository and the master requirements under /docs.

Do not write application code yet.

Produce an implementation plan covering:
- application architecture
- database boundaries
- authorization
- audit trail
- electronic signatures
- file storage
- workflow engine
- testing
- validation
- future LIMS integration

Create/update:
- docs/architecture/system-architecture.md
- docs/architecture/database-architecture.md
- docs/architecture/security-architecture.md
- docs/architecture/workflow-architecture.md

Do not claim regulatory compliance.

At the end, summarize the plan and identify unresolved technical risks.
