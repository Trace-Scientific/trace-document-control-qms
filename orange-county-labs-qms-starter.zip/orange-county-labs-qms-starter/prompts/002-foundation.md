# Prompt 002 — Foundation

Implement the repository foundation.

Create:
- TypeScript project structure
- web application
- API/service layer
- PostgreSQL connection
- environment configuration
- linting
- formatting
- unit/integration test framework
- CI
- Docker development environment
- health endpoint

Do not implement business modules yet.

Run lint, typecheck, tests, and build. Fix failures before completion.
