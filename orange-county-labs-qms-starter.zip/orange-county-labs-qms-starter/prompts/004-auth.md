# Prompt 004 — Authentication and Authorization

Implement secure authentication and server-side authorization.

Requirements:
- secure password hashing
- sessions
- MFA-ready architecture
- role/permission authorization
- organization/tenant isolation
- rate limiting
- account lockout
- protected API routes

Write negative tests for:
- horizontal privilege escalation
- vertical privilege escalation
- cross-tenant access
- unauthenticated access

Never rely only on frontend authorization.
