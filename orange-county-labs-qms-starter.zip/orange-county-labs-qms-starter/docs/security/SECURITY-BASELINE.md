# Security Baseline

Initial controls:

- TLS in transit
- encryption at rest
- strong password hashing
- MFA-ready authentication
- session expiration
- rate limiting
- least privilege
- server-side authorization
- tenant isolation
- object-level authorization
- secure file validation
- malware-scanning abstraction
- audit logging
- backup and restore
- secret management outside source control

## High-risk actions

The following require explicit authorization and audit events:

- document approval
- document retirement
- record disposition
- electronic signature
- CAPA closure
- competency finalization
- audit finding finalization
- inspection evidence export

## Security testing

The project must include tests for:
- horizontal privilege escalation
- vertical privilege escalation
- cross-tenant access
- unauthorized file download
- unauthorized signature
- audit-trail mutation
- session abuse
