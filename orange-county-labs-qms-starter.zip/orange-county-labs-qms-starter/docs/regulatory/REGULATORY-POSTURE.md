# Regulatory Posture

The QMS is intended to support laboratory quality-system activities potentially relevant to CLIA, CAP, ISO 15189, and other applicable requirements.

Do not hard-code proprietary accreditation checklist content without appropriate rights.

Use a configurable accreditation requirement model:

accreditation_program
  -> requirement
  -> evidence
  -> gap/finding
  -> corrective action

The application should display evidence and workflow state, not make unsupported legal/regulatory conclusions.

Laboratory management must establish:
- applicable requirements;
- controlled procedures;
- implementation policies;
- validation;
- training;
- security controls;
- record retention;
- inspection readiness.
