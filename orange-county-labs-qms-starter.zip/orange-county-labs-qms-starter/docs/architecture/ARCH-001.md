# Architecture Decision Record — Initial Platform Architecture

## Status
Accepted baseline

## Decision
Use a modular TypeScript architecture with a Next.js web application, service/API layer, PostgreSQL relational database, object storage for files, background jobs, and dedicated security/audit/signature domains.

## Why

The system has regulated-record characteristics and requires:
- strong relational integrity;
- immutable historical records;
- configurable workflows;
- granular authorization;
- auditable actions;
- future LIMS integration.

## Boundaries

Business modules should not directly mutate audit records. Business modules should use domain services for regulated transitions.

Large files belong in object storage; PostgreSQL stores metadata, hashes, relationships, and control state.

## Future integration

The QMS should expose stable APIs/events rather than sharing the future LIMS database directly.
