# Initial Data Model

## Core tenancy

organizations
sites
departments

## Identity

users
roles
permissions
user_roles
role_permissions

## Documents

document_types
documents
document_versions
document_approvals
document_acknowledgments

## Files

files

## Records

record_types
records
retention_policies

## Personnel

employees
employee_credentials
employee_qualifications
job_descriptions
employee_job_assignments

## Training

training_courses
training_assignments
training_records

## Competency

competency_programs
competency_elements
competency_assessments

## Quality

quality_events
event_investigations
root_cause_analyses
capas
risks

## Operations

equipment
equipment_events
reagents
reagent_lots
tests
validation_projects
validation_results
pt_programs
pt_events

## Audits

audits
audit_findings
management_reviews

## Accreditation

accreditation_programs
requirements
requirement_evidence

## Cross-cutting

workflow_definitions
workflow_steps
workflow_assignments
electronic_signatures
audit_events
notifications
