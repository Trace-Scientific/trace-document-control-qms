# Release Readiness Checklist

- [ ] Requirements updated
- [ ] Architecture reviewed
- [ ] Database migrations tested from clean state
- [ ] Authorization tests pass
- [ ] Audit trail tests pass
- [ ] Signature tests pass
- [ ] Workflow tests pass
- [ ] File-security tests pass
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] E2E tests pass
- [ ] Security review complete
- [ ] Backup/restore tested
- [ ] Validation artifacts updated
- [ ] Known risks documented
- [ ] No production PHI/PII in test fixtures
- [ ] No secrets in repository
- [ ] Regulatory claims reviewed
